package com.three19;

public class Bicycle extends TwoWheeled {
    private int gears;
    private double cost;
    private double weight;
    private String color;

    // Consolidated constructor with default values
    public Bicycle(int i, double d, double e, String string2 = 0, double cost = 0.0, double weight = 0.0, String color = "") {
        this.gears = gears;
        this.cost = cost;
        this.weight = weight;
        this.color = color;
    }

    // Method to display bicycle details
    public void outputData() {
        System.out.println("\nBicycle Details:");
        System.out.println("Gears  : " + gears);
        System.out.println("Cost   : " + cost);
        System.out.println("Weight : " + weight + " lbs");
        System.out.println("Color  : " + color);
    }

    // Overloaded method to display bicycle details with custom text
    public Bicycle outputData(String bikeText) {
        System.out.println("\nBicycle " + bikeText + " Details:");
        System.out.println("Gears  : " + gears);
        System.out.println("Cost   : " + cost);
        System.out.println("Weight : " + weight + " lbs");
        System.out.println("Color  : " + color);

        return this; // Enable method chaining
    }

    // Getters and setters with method chaining for setters
    public int getGears() { return gears; }
    public Bicycle setGears(int gears) { this.gears = gears; return this; }

    public double getCost() { return cost; }
    public Bicycle setCost(double cost) { this.cost = cost; return this; }

    public double getWeight() { return weight; }
    public Bicycle setWeight(double weight) { this.weight = weight; return this; }

    public String getColor() { return color; }
    public Bicycle setColor(String color) { this.color = color; return this; }
}
