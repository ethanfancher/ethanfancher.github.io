package com.three19;

public class TwoWheeled extends Vehicle {
    private boolean hasPedals;
    private int wheelSize;

    // Constructor
    public TwoWheeled(String brand, String model, int year, boolean hasPedals, int wheelSize) {
        super(brand, model, year);
        this.hasPedals = hasPedals;
        this.wheelSize = wheelSize;
    }

    // Accessor methods
    public boolean hasPedals() {
        return hasPedals;
    }

    public int getWheelSize() {
        return wheelSize;
    }

    // Mutator methods
    public void setHasPedals(boolean hasPedals) {
        this.hasPedals = hasPedals;
    }

    public void setWheelSize(int wheelSize) {
        this.wheelSize = wheelSize;
    }

    @Override
    public String toString() {
        return super.toString() + ", hasPedals=" + hasPedals + ", wheelSize=" + wheelSize + " inches";
    }
}
