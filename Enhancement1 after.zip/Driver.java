package com.three19;

public class Driver {
    public static void main(String[] args) {
        // Create and manipulate Bicycle objects
        Bicycle myBike = new Bicycle(24, 319.99, 13.5, "Purple");
        System.out.println("\nmyBike's color is: " + myBike.getColor());

        // Output data for multiple bicycles with different constructors
        Bicycle[] bicycles = new Bicycle[]{
            new Bicycle(),
            new Bicycle("Brown"),
            new Bicycle(22),
            new Bicycle(22, 319.99, 13.5, "White")
        };

        for (int i = 0; i < bicycles.length; i++) {
            bicycles[i].outputData("Bicycle " + (i + 1));
        }

        // Demonstrate method call chaining
        Bicycle myChainedBike = new Bicycle(24, 418.50, 17.2, "Green")
                                .setColor("Peach")
                                .setGears(32);
        myChainedBike.outputData("Chained Bike");

        // Perform "instance of" checks for Bicycle
        checkInstance("Bicycle", myChainedBike);

        // Perform "instance of" checks for TwoWheeled
        TwoWheeled myTwoWheeled = new TwoWheeled("Generic", "Model", 2020, true, 26);
        checkInstance("TwoWheeled", myTwoWheeled);

        // Perform "instance of" checks for Vehicle
        Vehicle myVehicle = new Vehicle("Ford", "Mustang", 2022);
        checkInstance("Vehicle", myVehicle);
    }

    private static void checkInstance(String className, Object obj) {
        System.out.println("\nInstance checks for " + className + ":");
        System.out.println("Instance of Bicycle: " + (obj instanceof Bicycle));
        System.out.println("Instance of TwoWheeled: " + (obj instanceof TwoWheeled));
        System.out.println("Instance of Vehicle: " + (obj instanceof Vehicle));
        System.out.println("Instance of Object: " + (obj instanceof Object));
    }
}
