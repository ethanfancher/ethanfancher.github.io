//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : Ethan Fancher
// Version     : 1.0
// Date        : 4/10/23
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <iostream>
#include <algorithm>
#include <time.h>
#include <vector>
#include <fstream>
#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// Forward declarations
double strToDouble(string str, char ch);

// Define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() : amount(0.0) {}
};

// Internal structure for tree node
struct Node {
    Bid bid;
    Node* left; // pointer for values < parent
    Node* right; // pointer for values > parent
    int height;

    // Default constructor
    Node() : left(nullptr), right(nullptr), height(1) {}

    // Custom constructor with a bid param
    Node(Bid aBid) : Node() {
        bid = aBid;
    }
};

//============================================================================
// Binary Search Tree class definition
//============================================================================

class BinarySearchTree {
private:
    Node* root;

    Node* addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    Node* removeNode(Node* node, string bidId);
    int height(Node* node);
    int getBalance(Node* node);
    Node* rotateRight(Node* y);
    Node* rotateLeft(Node* x);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Bid bid);
    void Remove(string bidId);
    Bid Search(string bidId);
};

BinarySearchTree::BinarySearchTree() : root(nullptr) {}

BinarySearchTree::~BinarySearchTree() {
    // Recurse from root deleting every node
}

int BinarySearchTree::height(Node* node) {
    if (node == nullptr)
        return 0;
    return node->height;
}

int BinarySearchTree::getBalance(Node* node) {
    if (node == nullptr)
        return 0;
    return height(node->left) - height(node->right);
}

Node* BinarySearchTree::rotateRight(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;
}

Node* BinarySearchTree::rotateLeft(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

void BinarySearchTree::Insert(Bid bid) {
    root = addNode(root, bid);
}

Node* BinarySearchTree::addNode(Node* node, Bid bid) {
    if (node == nullptr) {
        return new Node(bid);
    }

    if (bid.bidId < node->bid.bidId) {
        node->left = addNode(node->left, bid);
    }
    else if (bid.bidId > node->bid.bidId) {
        node->right = addNode(node->right, bid);
    }
    else {
        return node;
    }

    node->height = 1 + max(height(node->left), height(node->right));
    int balance = getBalance(node);

    // Left Left Case
    if (balance > 1 && bid.bidId < node->left->bid.bidId)
        return rotateRight(node);

    // Right Right Case
    if (balance < -1 && bid.bidId > node->right->bid.bidId)
        return rotateLeft(node);

    // Left Right Case
    if (balance > 1 && bid.bidId > node->left->bid.bidId) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    // Right Left Case
    if (balance < -1 && bid.bidId < node->right->bid.bidId) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

void BinarySearchTree::InOrder() {
    inOrder(root);
}

void BinarySearchTree::inOrder(Node* node) {
    if (node != nullptr) {
        inOrder(node->left);
        cout << node->bid.bidId << ": " << node->bid.title << " | " << node->bid.amount << " | "
            << node->bid.fund << endl;
        inOrder(node->right);
    }
}

Node* BinarySearchTree::removeNode(Node* node, string bidId) {
    if (node == nullptr) {
        return node;
    }

    // If the bidId is less than the node's bidId, it lies in the left subtree
    if (bidId < node->bid.bidId) {
        node->left = removeNode(node->left, bidId);
    }
    // If the bidId is greater than the node's bidId, it lies in the right subtree
    else if (bidId > node->bid.bidId) {
        node->right = removeNode(node->right, bidId);
    }
    // If key is same as root's key, then this is the node to be deleted
    else {
        // node with only one child or no child
        if ((node->left == nullptr) || (node->right == nullptr)) {
            Node* temp = node->left ? node->left : node->right;

            // No child case
            if (temp == nullptr) {
                temp = node;
                node = nullptr;
            }
            else // One child case
                *node = *temp; // Copy the contents of the non-empty child

            delete temp;
        }
        else {
            // node with two children: Get the inorder successor (smallest in the right subtree)
            Node* temp = node->right;
            while (temp->left != nullptr)
                temp = temp->left;

            // Copy the inorder successor's data to this node
            node->bid = temp->bid;

            // Delete the inorder successor
            node->right = removeNode(node->right, temp->bid.bidId);
        }
    }

    // If the tree had only one node then return
    if (node == nullptr)
        return node;

    // UPDATE HEIGHT OF THE CURRENT NODE
    node->height = 1 + max(height(node->left), height(node->right));

    // GET THE BALANCE FACTOR OF THIS NODE (to check whether this node became unbalanced)
    int balance = getBalance(node);

    // If this node becomes unbalanced, then there are 4 cases

    // Left Left Case
    if (balance > 1 && getBalance(node->left) >= 0)
        return rotateRight(node);

    // Left Right Case
    if (balance > 1 && getBalance(node->left) < 0) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    // Right Right Case
    if (balance < -1 && getBalance(node->right) <= 0)
        return rotateLeft(node);

    // Right Left Case
    if (balance < -1 && getBalance(node->right) > 0) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | " << bid.fund << endl;
}

void loadBids(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;
    csv::Parser file = csv::Parser(csvPath);

    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        for (unsigned int i = 0; i < file.rowCount(); i++) {
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');
            bst->Insert(bid);
        }
    }
    catch (csv::Error& e) {
        cerr << e.what() << endl;
    }
}

double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

int main(int argc, char* argv[]) {
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98109";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        bidKey = "98109";
    }

    clock_t ticks;
    BinarySearchTree* bst = new BinarySearchTree();
    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            ticks = clock();
            loadBids(csvPath, bst);
            ticks = clock() - ticks;
            cout << "Time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            bst->InOrder();
            break;

        case 3:
            ticks = clock();
            bid = bst->Search(bidKey);
            ticks = clock() - ticks;
            if (!bid.bidId.empty()) {
                displayBid(bid);
            }
            else {
                cout << "Bid Id " << bidKey << " not found." << endl;
            }
            cout << "Time: " << ticks << " clock ticks" << endl;
            cout << "Time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 4:
            bst->Remove(bidKey);
            break;
        }
    }

    cout << "Goodbye." << endl;
    return 0;
}