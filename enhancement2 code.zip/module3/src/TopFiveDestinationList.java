import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top Five Detox destinations");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}

class TopDestinationListFrame extends JFrame {
    private DefaultListModel<TextAndIcon> listModel;

    public TopDestinationListFrame() {
        super("Top Five Detox destinations");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel<>();

        // Add destinations
        addDestinationNameAndPicture("Deer Lake Lodge, Montgomery, Texas", new ImageIcon(getClass().getResource("/resources/download.jpg")));
        addDestinationNameAndPicture("Sedona Wellness Retreat, Sedona, AZ", new ImageIcon(getClass().getResource("/resources/download (1).jpg")));
        addDestinationNameAndPicture("We Care Spa, Desert Hot Springs, California", new ImageIcon(getClass().getResource("/resources/download (2).jpg")));
        addDestinationNameAndPicture("Balance for Life Florida, Deerfield Beach, Florida", new ImageIcon(getClass().getResource("/resources/download (3).jpg")));
        addDestinationNameAndPicture("COR Retreat, Wayzata, Minnesota", new ImageIcon(getClass().getResource("/resources/download (4).jpg")));

        JList<TextAndIcon> list = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);
        list.setCellRenderer(renderer);
        list.setBackground(Color.gray);

        JLabel nameLabel = new JLabel("Developer: Ethan Fancher");
        getContentPane().add(nameLabel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Add sort button
        JButton sortButton = new JButton("Sort Destinations");
        sortButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sortDestinations();
            }
        });
        getContentPane().add(sortButton, BorderLayout.SOUTH);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }

    private void sortDestinations() {
        List<TextAndIcon> destinationList = new ArrayList<>();
        for (int i = 0; i < listModel.size(); i++) {
            destinationList.add(listModel.get(i));
        }
        Collections.sort(destinationList, new TextAndIconComparator());
        listModel.clear();
        for (TextAndIcon tai : destinationList) {
            listModel.addElement(tai);
        }
    }
}

class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }
}

class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer<TextAndIcon> {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);
    private Border insideBorder;

    // Updated constructor to accept a single padding parameter
    public TextAndIconListCellRenderer(int padding) {
        insideBorder = BorderFactory.createEmptyBorder(padding, padding, padding, padding);
        setOpaque(true);
    }

    @Override
    public Component getListCellRendererComponent(JList<? extends TextAndIcon> list, TextAndIcon value, int index, boolean isSelected, boolean cellHasFocus) {
        setText(value.getText());
        setIcon(value.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder = cellHasFocus ? UIManager.getBorder("List.focusCellHighlightBorder") : NO_FOCUS_BORDER;
        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }
}

class TextAndIconComparator implements Comparator<TextAndIcon> {
    @Override
    public int compare(TextAndIcon o1, TextAndIcon o2) {
        return o1.getText().compareToIgnoreCase(o2.getText());
    }
}
